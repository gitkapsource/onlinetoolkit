import React from "react";
export default function Navbar() {
  return (
    <nav className="bg-white shadow p-4 text-xl font-semibold text-gray-800">
      OCR Toolkit Clone
    </nav>
  );
}